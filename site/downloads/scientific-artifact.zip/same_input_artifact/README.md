# Same Input, Different Score — scientific artifact

Run make -C reproducibility_artifact reproduce for public verification, install-scorers replay for three genuine historical scorer fixtures, and figure-env figures for plots. See docs/REPRODUCIBILITY.md and docs/METHODS_AND_LIMITATIONS.md. Website source/build commands apply to the repository, not this scientific-only archive. Full empirical replay requires restricted inputs. No manuscript is bundled.
